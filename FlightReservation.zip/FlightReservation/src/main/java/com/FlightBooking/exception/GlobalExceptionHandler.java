package com.FlightBooking.exception;

import com.FlightBooking.payload.ErrorDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Date;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(CredentialExists.class)
    public String invalidPathException(
            ErrorDetails errorexception,
            WebRequest webRequest

    ){
        ErrorDetails errorDetails = new ErrorDetails(new Date(), errorexception.getMessage(), webRequest.getDescription(true));
        return new  String(errorDetails.toString());
    }
    @ExceptionHandler(UserNotFoundException.class)
    public String usernotnotfounexvString(
            ErrorDetails errorexception,
            WebRequest webRequest

    ){
        ErrorDetails errorDetails = new ErrorDetails(new Date(), errorexception.getMessage(), webRequest.getDescription(true));
        return new  String(errorDetails.toString());
    }


}
