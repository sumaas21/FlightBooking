package com.FlightBooking.entity;

import lombok.*;

import javax.management.relation.Role;
import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
@Table(name = "User_Details")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotEmpty
    private String name;
    @NotEmpty
    private String username;



    @NotEmpty
    private  String email;
    @Size(min = 10 ,max = 10,message = "Mobile Number should be of digits")
    private long mobile;

    private String password;





}
