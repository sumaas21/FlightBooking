package com.FlightBooking.entity;

import lombok.*;
import net.bytebuddy.dynamic.loading.InjectionClassLoader;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Bookings")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotEmpty
    private String PassengerName;
    @NotEmpty
    private String Email;
    @Size(min = 10,max = 10,message = "Mobile Number should be of 10 digits")
    private String Mobile;

    @NotNull
    private long PaidAmount;



}
