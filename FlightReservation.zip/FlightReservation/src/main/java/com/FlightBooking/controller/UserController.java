package com.FlightBooking.controller;


import com.FlightBooking.entity.User;
import com.FlightBooking.exception.CredentialExists;
import com.FlightBooking.repository.userrepo;
import com.FlightBooking.service.BookingService;
import com.FlightBooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private userrepo userrepo;


    @RequestMapping("/signup")
    public String signup(@Valid @RequestParam("name") String name,
                         @Valid @RequestParam("email") String email,
                         @Valid @RequestParam("mobile") long mobile,
                         @RequestParam("password") String password,
                         BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            return new String(bindingResult.getFieldError().getDefaultMessage());
        }

  if(userrepo.existsByEmail(email)){
      throw new CredentialExists("Email Already Registered ");
  }
        if(userrepo.existsByMobile(mobile)){
            throw new CredentialExists("Mobile Already Registered ");
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setMobile(mobile);
        String signupservice = userService.signupservice(user);
        if (signupservice == "Loggedin") {
            return "main";
        } else {
            model.addAttribute("Error occued ,User not sighned in");
            return "login";
        }
    }

    @RequestMapping("/login")
    public String login(@RequestParam("email")String email,@RequestParam("Password")String password,Model model){
                 if(userrepo.existsByEmail(email) && userrepo.existsByPassword(password)){
                   return "main";
                 }
                 else{
                     model.addAttribute("Invalid Credentials");
                     return "logind";
                 }


    }
}
