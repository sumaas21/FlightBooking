package com.FlightBooking.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.FlightBooking.entity.FlightDetails;

public interface BookingRepository extends JpaRepository<FlightDetails,Long> {

   List<FlightDetails>findByOriginatingAndDestination(String originating , String destination);
}
