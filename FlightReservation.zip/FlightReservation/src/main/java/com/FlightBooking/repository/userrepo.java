package com.FlightBooking.repository;

import com.FlightBooking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface userrepo extends JpaRepository<User,Long> {

    Boolean existsByEmail(String email);

    Boolean existsByPassword(String password);

    Boolean existsByMobile(long mobile);

    Optional<User> findByUsernameOrEmail(String username,String email);

    Optional<User> findByPassword(String password);

}
