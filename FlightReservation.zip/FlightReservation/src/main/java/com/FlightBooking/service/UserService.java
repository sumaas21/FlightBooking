package com.FlightBooking.service;

import com.FlightBooking.entity.User;
import com.FlightBooking.repository.userrepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private userrepo userrepo;

    public  String signupservice(User user){
        userrepo.save(user);

        return "Loggedin";

    }

}
