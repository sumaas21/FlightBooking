package com.FlightBooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FlightBooking.entity.FlightDetails;
import com.FlightBooking.repository.BookingRepository;

@Service
public class BookingService {
	
	@Autowired
	public BookingRepository bookingrepo;




	
	public void saveRecord(FlightDetails flightDetails) {
		
		bookingrepo.save(flightDetails);
	}
	
	public List<FlightDetails>ReadBooking() {
		List<FlightDetails> record = bookingrepo.findAll();
		return record;
		
	}
	
	public void deleterecord(long id) {
	bookingrepo.deleteById(id);
	}
     
	public void updatesave(FlightDetails flightDetails) {
		bookingrepo.save(flightDetails);
	}
	
	public FlightDetails getById(long id) {
		Optional<FlightDetails> booking = bookingrepo.findById(id);
		return booking.get();
	}
	
	public List<FlightDetails> Search(String originating , String destination){
		List<FlightDetails> searched = bookingrepo.findByOriginatingAndDestination(originating, destination);
		return searched;
		
	}
}
